import React from 'react';

const Samerica = () => {
  return (
    <div>
      <h2>Bienvenue En Amérique du Sud</h2>
      <p>Contenu spécifique à l'Amérique du Sud.</p>
    </div>
  );
};

export default Samerica;
